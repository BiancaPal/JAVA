/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java25_string;

/**
 *
 * @author Alex
 */
public class java25_string {
     public static void main(String[] args) {  
	String str = "Substituir una paraula";
	
        System.out.println(str.replace("una", "la"));
	
   }  
}
