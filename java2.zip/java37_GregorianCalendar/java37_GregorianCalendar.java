/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java37_GregorianCalendar;

import java.util.GregorianCalendar;
/**
 *
 * @author Alex
 */
public class java37_GregorianCalendar {
     public static void main(String args[]){  
       
        
       GregorianCalendar calendari;
       
       calendari = new GregorianCalendar();
       
       calendari.set(1973, 6, 23);
      
       System.out.print(calendari.getTime() );
      

          
          
          
        
    }
}
