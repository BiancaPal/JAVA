/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java04_int;

/**
 *
 * @author Alex
 */
public class java04_int {
         public static void main(String[] args){
    int numero1 = 8;
    int numero2 = 5;
    int suma = numero1 + numero2;
    int resta = numero1 - numero2;
    int multip = numero1 * numero2;
    int div = numero1 / numero2;
    int modul = numero1 % numero2;
    
    
    System.out.println("Suma: "+suma);
    System.out.println("Resta: "+resta);
    System.out.println("Multiplicació: "+multip);
    System.out.println("Divisió: "+div);
    System.out.println("Módul: "+modul);
    
     }
}
    