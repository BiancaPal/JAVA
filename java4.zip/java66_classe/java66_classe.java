/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java66_classe;

/**
 *
 * @author Alex
 */
public class java66_classe {
    
    private String nom;
    private Double nota;
    
    public Double getNota(){
        return nota;
    }
    
    public String getNom(){
        return nom;
    }
    
    
}
