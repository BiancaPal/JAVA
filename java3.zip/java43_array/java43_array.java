/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java43_array;

/**
 *
 * @author Alex
 */

import java.util.Arrays;

public class java43_array {
     public static void main(String[] args)
    {
     
           
         String [] alfabet = {"A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "W", "X", "Y", "Z"};
         
         for (String alfa: alfabet){
             System.out.print(alfa);
         }
         
         System.out.print("\n"+Arrays.toString(alfabet));
         
         
         
           
           
           
            
    }
}
